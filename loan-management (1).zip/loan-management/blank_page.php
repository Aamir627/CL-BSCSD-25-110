<?php
include_once "inc/header.php";
include_once "inc/sidebar.php";
?>
<div class="card">
	<div class="card-header">
		Applier Information
	</div>
	<div class="card-body">
		<h5 class="card-title">Special title treatment</h5>
		<table id="example" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>Name</th>
					<th>Position</th>
					<th>Office</th>
					<th>Age</th>
					<th>Start date</th>
					<th>Salary</th>
				</tr>
			</thead>
			<tfoot>
			</tbody>
		</table>
	</div>
</div>

<?php
include_once "inc/footer.php";
?>